@echo off
REM push_to_github.bat - Push code to GitHub using a personal access token
REM Usage: Double-click this file, then enter your GitHub username and PAT when prompted
REM Or: Edit the lines below to hardcode your credentials

set GITHUB_USERNAME=your_github_username
set GITHUB_TOKEN=your_personal_access_token_here
set REPO_URL=https://github.com/Be1l-ai/grocery-item-demo.git

REM Configure git to use the token
git config --global credential.helper store

REM Write credentials to .git-credentials file
echo https://%GITHUB_USERNAME%:%GITHUB_TOKEN%@github.com > %USERPROFILE%\.git-credentials

REM Remove existing remote and re-add with token embedded in URL
git remote remove origin
git remote add origin https://%GITHUB_USERNAME%:%GITHUB_TOKEN%@github.com/Be1l-ai/grocery-item-demo.git

REM Push to GitHub
git push -u origin master

echo.
echo Push complete! Check https://github.com/Be1l-ai/grocery-item-demo for your files.
pause