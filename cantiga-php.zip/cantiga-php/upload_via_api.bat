@echo off
REM upload_via_api.bat - Upload files to GitHub via API using token from file
REM Step 1: Save your GitHub PAT to C:\temp\github_token.txt (just the token, nothing else)
REM Step 2: Run this script

set TOKEN_FILE=C:\temp\github_token.txt
set REPO=Be1l-ai/grocery-item-demo

REM Read token from file
set /p GITHUB_TOKEN=<"%TOKEN_FILE%"

REM Get the current commit SHA to get the tree SHA
for /f "delims=" %%i in ('curl.exe -s -H "Authorization: token %GITHUB_TOKEN%" -H "Accept: application/vnd.github.v3+json" "https://api.github.com/repos/%REPO%" ^| findstr "default_branch_commit_sha sha"') do set RESPONSE=%%i

echo Uploading files via GitHub API...

REM Upload each file using the Contents API
REM (Note: This batch script is a template - actual file uploads via API require base64 encoding)

curl.exe -s -X PUT -H "Authorization: token %GITHUB_TOKEN%" -H "Accept: application/vnd.github.v3+json" ^
  "https://api.github.com/repos/%REPO%/contents/sql/schema_grocery_mexico.sql" ^
  -d "{\"message\":\"Add schema_grocery_mexico.sql\",\"content\":\"BASE64_ENCODED_CONTENT\"}"

echo File uploaded.

pause